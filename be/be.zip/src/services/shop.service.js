"use strict";

const {
  BadRequestError,
  NotFoundError,
  ForbiddenError,
} = require("../configs/error.response");
const shopModel = require("../models/shop.model");
const shopImageModel = require("../models/shopImage.model");
const shopSeatModel = require("../models/shopSeat.model");
const shopMenuItemModel = require("../models/shopMenuItem.model");
const shopTimeSlotModel = require("../models/shopTimeSlot.model");
const shopVerificationModel = require("../models/shopVerification.model");
const cloudinary = require("cloudinary").v2;
const {
  getInfoData,
  getSelectData,
  removeUndefinedObject,
} = require("../utils");
const { getPaginatedData } = require("../helpers/mongooseHelper");
const menuItemCategoryModel = require("../models/menuItemCategory.model");
const mongoose = require("mongoose");
const shopAmenityModel = require("../models/shopAmenity.model");
const { calculateDistance, getDistanceFromLatLonInKm } = require("../utils/distanceCaculate");

const getAllPublicShops = async (req) => {
  try {
    const {
      page = 1,
      limit = 10,
      sortBy = "rating_avg",
      sortOrder = "desc",
      amenities,
      search,
      latitude,
      longitude,
      themes,
      radius = 5000
    } = req.query;

    // Kiểm tra tham số đầu vào
    if ((latitude && !longitude) || (!latitude && longitude)) {
      throw new BadRequestError("Both latitude and longitude must be provided");
    }
    if (latitude && longitude) {
      if (isNaN(parseFloat(latitude)) || isNaN(parseFloat(longitude))) {
        throw new BadRequestError("latitude and longitude must be valid numbers");
      }
      if (isNaN(parseInt(radius)) || parseInt(radius) < 0) {
        throw new BadRequestError("radius must be a non-negative number");
      }
    }
    if (amenities && !Array.isArray(amenities.split(","))) {
      throw new BadRequestError("amenities must be a comma-separated string");
    }
    if (themes && !Array.isArray(themes.split(","))) {
      throw new BadRequestError("themes must be a comma-separated string");
    }


    // Xây dựng query
    const query = {
      status: "Active",
    };

    // Lọc theo amenities
    if (amenities) {
      const amenityIds = amenities.split(",").map(id => 
        new mongoose.Types.ObjectId(id.trim())
      );
      query.amenities = { $all: amenityIds };
    }

    if (themes) {
      const themeIds = themes.split(",").map(id => 
        new mongoose.Types.ObjectId(id.trim())
      );
      query.theme_ids = { $all: themeIds };
    }

    // Tìm kiếm theo vị trí gần (nếu có latitude và longitude)
    if (latitude && longitude) {
      // $geoWithin with $centerSphere for radius in kilometers
      query.location = {
        $geoWithin: {
          $centerSphere: [
            [parseFloat(longitude), parseFloat(latitude)],
            parseFloat(radius) / 6378.1 // radius in radians (km / earth radius in km)
          ]
        }
      };
    }

    // Xây dựng sort
    const validSortFields = [
      "rating_avg",
      "rating_count",
      "name",
      "createdAt",
      "updatedAt",
    ];
    if (sortBy && !validSortFields.includes(sortBy)) {
      throw new BadRequestError(
        `Invalid sortBy. Must be one of: ${validSortFields.join(", ")}`
      );
    }
    const sort = { [sortBy]: sortOrder === "asc" ? 1 : -1 };

    // Cấu hình cho getPaginatedData
    const paginateOptions = {
      model: shopModel,
      query,
      page,
      limit,
      select: getSelectData([
        "_id",
        "name",
        "address",
        "description",
        "location",
        "phone",
        "website",
        "theme_ids",
        "vip_status",
        "rating_avg",
        "rating_count",
        "amenities",
        "opening_hours",
        "formatted_opening_hours",
        "is_open",
        "createdAt",
        "updatedAt",
      ]),
      populate: [
        { path: "theme_ids", select: "_id name description theme_image" },
        { path: "amenities", select: "_id icon label" },
      ],
      search,
      searchFields: ["name"],
      sort,
    };

    // Lấy dữ liệu phân trang
    const result = await getPaginatedData(paginateOptions);

    // Lấy ảnh chính cho mỗi quán
    const shopsWithImage = await Promise.all(
      result.data.map(async (shop) => {


        const mainImage = await shopImageModel
          .findOne({ shop_id: shop._id })
          .select("url publicId")
          .lean();
        return {
          ...getInfoData({
            fields: [
              "_id",
              "name",
              "address",
              "location",
              "description",
              "phone",
              "website",
              "theme_ids",
              "vip_status",
              "rating_avg",
              "rating_count",
              "amenities",
              "opening_hours",
              "formatted_opening_hours",
              "is_open",
              "createdAt",
              "updatedAt",
            ],
            object: shop,
          }),
          mainImage: mainImage
            ? { url: mainImage.url, publicId: mainImage.publicId }
            : null,
        };
      })
    );

    const shopsWithDistance = shopsWithImage.map(shop => {
      const distance = getDistanceFromLatLonInKm(parseFloat(longitude), parseFloat(latitude), parseFloat(shop.location.coordinates[0]), parseFloat(shop.location.coordinates[1]));

      return {
        ...shop,
        distance: distance
      };
    });

    return {
      shops: shopsWithDistance,
      metadata: {
        totalItems: result.metadata.total,
        totalPages: result.metadata.totalPages,
        currentPage: result.metadata.page,
        limit: result.metadata.limit,
      },
      message: shopsWithImage.length === 0 ? "No public shops found" : undefined,
    };
  } catch (error) {
    throw error instanceof BadRequestError
      ? error
      : new BadRequestError(error.message || "Failed to retrieve public shops");
  }
};

const createShop = async (req) => {
  try {
    const { userId } = req.user;
    const {
      name,
      address,
      description,
      phone,
      website,
      latitude,
      longitude,
      amenities,
      theme_ids,
      opening_hours
    } = req.body;

    // Kiểm tra input bắt buộc
    if (!name || !address || !description || !phone || !website || typeof latitude === 'undefined' || typeof longitude === 'undefined') {
      throw new BadRequestError("Name, address, description, phone, website, latitude, and longitude are required");
    }

    // Validate opening_hours
    if (opening_hours) {
      if (!Array.isArray(opening_hours)) {
        throw new BadRequestError("opening_hours must be an array");
      }
      const validDays = [0, 1, 2, 3, 4, 5, 6];
      const timeRegex = /^([0-1]\d|2[0-3]):[0-5]\d$/;
      for (const entry of opening_hours) {
        if (!validDays.includes(entry.day)) {
          throw new BadRequestError("Invalid day in opening_hours (must be 0-6)");
        }
        // Nếu là ngày đóng cửa thì bỏ qua kiểm tra hours
        if (entry.is_closed) continue;
        if (!entry.hours || !Array.isArray(entry.hours) || entry.hours.length === 0) {
          throw new BadRequestError(`Hours required for day ${entry.day} when not closed`);
        }
        for (const h of entry.hours) {
          if (!timeRegex.test(h.open) || !timeRegex.test(h.close)) {
            throw new BadRequestError(`Invalid time format in hours for day ${entry.day}`);
          }
          // Nếu mở 24/24 thì open: 00:00, close: 23:59 là hợp lệ
          const [openHour, openMinute] = h.open.split(":").map(Number);
          const [closeHour, closeMinute] = h.close.split(":").map(Number);
          const openTime = openHour * 60 + openMinute;
          const closeTime = closeHour * 60 + closeMinute;
          if (openTime >= closeTime) {
            throw new BadRequestError(`Open time must be before close time for day ${entry.day}`);
          }
        }
      }
    }

    // Convert amenities sang ObjectId nếu là string
    let amenitiesIds = undefined;
    if (Array.isArray(amenities)) {
      amenitiesIds = amenities
        .filter((id) => mongoose.Types.ObjectId.isValid(id))
        .map((id) => new mongoose.Types.ObjectId(id));
    }

    // Convert theme_ids sang ObjectId nếu là string
    let themeIds = undefined;
    if (Array.isArray(theme_ids)) {
      themeIds = theme_ids
        .filter((id) => mongoose.Types.ObjectId.isValid(id))
        .map((id) => new mongoose.Types.ObjectId(id));
    }

    // Tạo quán mới
    const shop = await shopModel.create({
      name,
      address,
      description,
      phone,
      website,
      location: {
        type: "Point",
        coordinates: [
          parseFloat(longitude),
          parseFloat(latitude)
        ],
      },
      owner_id: userId,
      amenities: amenitiesIds,
      theme_ids: themeIds,
      opening_hours,
    });

    return {
      shop: getInfoData({
        fields: [
          "_id",
          "name",
          "address",
          "description",
          "phone",
          "website",
          "location",
          "owner_id",
          "theme_ids",
          "amenities",
          "opening_hours",
          "createdAt",
          "updatedAt",
        ],
        object: shop,
      }),
    };
  } catch (error) {
    throw error instanceof BadRequestError
      ? error
      : new BadRequestError(error.message || "Failed to create shop");
  }
};


const updateShop = async (req) => {
  try {
    const { shopId } = req.params;
    const { userId } = req.user;
    const { name, address, description, phone, website, latitude, longitude, amenities, theme_ids, opening_hours } = req.body;

    // Tìm shop
    const shop = await shopModel.findById(shopId);
    if (!shop) throw new NotFoundError("Shop not found");

    // Kiểm tra quyền sở hữu
    if (shop.owner_id.toString() !== userId) {
      throw new ForbiddenError("You are not the owner of this shop");
    }

    // Validate opening_hours nếu có
    if (opening_hours) {
      if (!Array.isArray(opening_hours)) {
        throw new BadRequestError("opening_hours must be an array");
      }
      const validDays = [0, 1, 2, 3, 4, 5, 6];
      const timeRegex = /^([0-1]\d|2[0-3]):[0-5]\d$/;
      for (const entry of opening_hours) {
        if (!validDays.includes(entry.day)) {
          throw new BadRequestError("Invalid day in opening_hours (must be 0-6)");
        }
        if (entry.is_closed) continue;
        if (!entry.hours || !Array.isArray(entry.hours) || entry.hours.length === 0) {
          throw new BadRequestError(`Hours required for day ${entry.day} when not closed`);
        }
        for (const h of entry.hours) {
          if (!timeRegex.test(h.open) || !timeRegex.test(h.close)) {
            throw new BadRequestError(`Invalid time format in hours for day ${entry.day}`);
          }
          const [openHour, openMinute] = h.open.split(":").map(Number);
          const [closeHour, closeMinute] = h.close.split(":").map(Number);
          const openTime = openHour * 60 + openMinute;
          const closeTime = closeHour * 60 + closeMinute;
          if (openTime >= closeTime) {
            throw new BadRequestError(`Open time must be before close time for day ${entry.day}`);
          }
        }
      }
    }

    // amenities: convert sang ObjectId nếu là string
    let amenitiesIds;
    if (Array.isArray(amenities)) {
      amenitiesIds = amenities
        .filter((id) => mongoose.Types.ObjectId.isValid(id))
        .map((id) => new mongoose.Types.ObjectId(id));
    }

    // theme_ids: convert sang ObjectId nếu là string
    let themeIds;
    if (Array.isArray(theme_ids)) {
      themeIds = theme_ids
        .filter((id) => mongoose.Types.ObjectId.isValid(id))
        .map((id) => new mongoose.Types.ObjectId(id));
    }

    // location: chỉ update nếu có cả latitude và longitude
    let location;
    if (typeof latitude !== 'undefined' && typeof longitude !== 'undefined') {
      location = {
        type: "Point",
        coordinates: [parseFloat(longitude), parseFloat(latitude)],
      };
    }

    // Chuẩn bị dữ liệu update
    const updateData = removeUndefinedObject({
      name,
      address,
      description,
      phone,
      website,
      location,
      amenities: amenitiesIds,
      theme_ids: themeIds,
      opening_hours,
    });

    // Update shop
    const updatedShop = await shopModel.findByIdAndUpdate(
      shopId,
      updateData,
      { new: true, runValidators: true }
    ).select(
      getSelectData([
        "_id",
        "name",
        "address",
        "description",
        "phone",
        "website",
        "location",
        "owner_id",
        "theme_ids",
        "vip_status",
        "rating_avg",
        "rating_count",
        "status",
        "amenities",
        "opening_hours",
        "createdAt",
        "updatedAt",
      ])
    );

    return {
      shop: getInfoData({
        fields: [
          "_id",
          "name",
          "address",
          "location",
          "description",
          "phone",
          "website",
          "owner_id",
          "theme_ids",
          "vip_status",
          "rating_avg",
          "rating_count",
          "status",
          "description",
          "amenities",
          "opening_hours",
          "createdAt",
          "updatedAt",
        ],
        object: updatedShop,
      }),
    };
  } catch (error) {
    if (error instanceof NotFoundError || error instanceof ForbiddenError) throw error;
    throw new BadRequestError(error.message || "Failed to update shop");
  }
};


const getShop = async (req) => {
  try {
    const { shopId } = req.params;

    const shop = await shopModel
      .findById(shopId)
      .populate([
        { path: "theme_ids", select: "_id name description theme_image" },
        { path: "amenities", select: "_id icon label" }
      ])
      .select(
        getSelectData([
          "_id",
          "name",
          "address",
          "description",
          "phone",
          "website",
          "location",
          "owner_id",
          "theme_ids",
          "vip_status",
          "rating_avg",
          "rating_count",
          "status",
          "amenities",
          "opening_hours",
          "formatted_opening_hours",
          "is_open",
          "createdAt",
          "updatedAt",
        ])
      )

    if (!shop) {
      throw new NotFoundError("Shop not found");
    }


    // Lấy thông tin liên quan
    const images = await shopImageModel
      .find({ shop_id: shopId })
      .select("url caption created_at")
      .lean();
    const seats = await shopSeatModel
      .find({ shop_id: shopId })
      .select("seat_name description image is_premium is_available capacity")
      .lean();
    const menuItems = await shopMenuItemModel
      .find({ shop_id: shopId })
      .select("name description price category images is_available")
      .lean();
    const timeSlots = await shopTimeSlotModel
      .find({ shop_id: shopId })
      .select(
        "day_of_week start_time end_time max_regular_reservations max_premium_reservations is_active"
      )
      .lean();
    const verifications = await shopVerificationModel
      .find({ shop_id: shopId })
      .select(
        "document_type document_url status submitted_at reviewed_at reason"
      )
      .lean();

    const result = {
      shop: {
        ...getInfoData({
          fields: [
            "_id",
            "name",
            "address",
            "description",
            "phone",
            "website",
            "location",
            "owner_id",
            "theme_ids",
            "vip_status",
            "rating_avg",
            "rating_count",
            "status",
            "amenities",
            "opening_hours",
            "formatted_opening_hours",
            "is_open",
            "createdAt",
            "updatedAt",
          ],
          object: shop,
        }),
        images,
        seats,
        menuItems,
        timeSlots,
        verifications,
      },
    };


    return result;
  } catch (error) {
    throw error instanceof NotFoundError || error instanceof ForbiddenError
      ? error
      : new BadRequestError(error.message || "Failed to retrieve shop");
  }
};

const getAllShops = async (req) => {
  try {
    const { userId, role } = req.user;
    const {
      page = 1,
      limit = 10,
      sortBy = "createdAt",
      sortOrder = "desc",
      status,
      amenities,
      search,
    } = req.query;

    // Kiểm tra tham số đầu vào
    if (amenities && !Array.isArray(amenities.split(","))) {
      throw new BadRequestError("amenities must be a comma-separated string");
    }
    if (status && !["Active", "Inactive", "Pending", "Rejected"].includes(status)) {
      throw new BadRequestError("Invalid status");
    }

    // Xây dựng query
    const query = {};

    // Lọc theo owner_id nếu không phải ADMIN
    if (role !== "ADMIN") {
      query.owner_id = userId;
    }

    // Lọc theo status
    if (status) {
      query.status = status;
    }

    // Lọc theo amenities
    if (amenities) {
      query.amenities = { $all: amenities.split(",").map((item) => item.trim()) };
    }

    // Xây dựng sort
    const validSortFields = [
      "createdAt",
      "updatedAt",
      "name",
      "rating_avg",
      "rating_count",
      "status",
    ];
    if (sortBy && !validSortFields.includes(sortBy)) {
      throw new BadRequestError(
        `Invalid sortBy. Must be one of: ${validSortFields.join(", ")}`
      );
    }
    const sort = { [sortBy]: sortOrder === "asc" ? 1 : -1 };

    // Cấu hình cho getPaginatedData
    const paginateOptions = {
      model: shopModel,
      query,
      page,
      limit,
      select: getSelectData([
        "_id",
        "name",
        "address",
        "description",
        "phone",
        "website",
        "location",
        "owner_id",
        "theme_ids",
        "vip_status",
        "rating_avg",
        "rating_count",
        "status",
        "amenities",
        "opening_hours",
        "formatted_opening_hours",
        "is_open",
        "createdAt",
        "updatedAt",
      ]),
      populate: [
        { path: "theme_ids", select: "_id name description theme_image" },
        { path: "amenities", select: "_id icon label" }
      ],
      search,
      searchFields: ["name"],
      sort,
    };

    // Lấy dữ liệu phân trang
    const result = await getPaginatedData(paginateOptions);

    // Format dữ liệu
    const shops = result.data.map((shop) =>
      getInfoData({
        fields: [
          "_id",
          "name",
          "address",
          "description",
          "phone",
          "website",
          "location",
          "owner_id",
          "theme_ids",
          "vip_status",
          "rating_avg",
          "rating_count",
          "status",
          "amenities",
          "opening_hours",
          "formatted_opening_hours",
          "is_open",
          "createdAt",
          "updatedAt",
        ],
        object: shop,
      })
    );

    return {
      shops,
      metadata: {
        totalItems: result.metadata.total,
        totalPages: result.metadata.totalPages,
        currentPage: result.metadata.page,
        limit: result.metadata.limit,
      },
      message: shops.length === 0 ? "No shops found" : undefined,
    };
  } catch (error) {
    throw error instanceof BadRequestError
      ? error
      : new BadRequestError(error.message || "Failed to retrieve shops");
  }
};


const uploadShopImage = async (req) => {
  try {
    const { shopId } = req.params;
    const { userId } = req.user;
    const { caption } = req.body;
    const file = req.file;

    // Tìm quán
    const shop = await shopModel.findById(shopId);
    if (!shop) {
      throw new NotFoundError("Shop not found");
    }

    // Kiểm tra quyền
    if (shop.owner_id.toString() !== userId) {
      throw new ForbiddenError("You are not the owner of this shop");
    }

    // Kiểm tra file
    if (!file) {
      throw new BadRequestError("Image file is required");
    }

    // Tạo ảnh mới
    const image = await shopImageModel.create({
      shop_id: shopId,
      url: file.path,
      caption,
    });

    return {
      image: getInfoData({
        fields: ["_id", "shop_id", "url", "caption", "created_at"],
        object: image,
      }),
    };
  } catch (error) {
    if (req.file && req.file.filename) {
      await cloudinary.uploader.destroy(req.file.filename);
    }
    throw error instanceof NotFoundError || error instanceof ForbiddenError
      ? error
      : new BadRequestError(error.message || "Failed to upload shop image");
  }
};

const assignThemes = async (req) => {
  try {
    const { shopId } = req.params;
    const { userId } = req.user;
    const { theme_ids } = req.body;

    // Tìm quán
    const shop = await shopModel.findById(shopId);
    if (!shop) {
      throw new NotFoundError("Shop not found");
    }

    // Kiểm tra quyền
    if (shop.owner_id.toString() !== userId) {
      throw new ForbiddenError("You are not the owner of this shop");
    }

    // Cập nhật theme_ids
    if (!Array.isArray(theme_ids)) {
      throw new BadRequestError("Theme IDs must be an array");
    }
    if (theme_ids.length === 0) {
      throw new BadRequestError("Theme IDs cannot be empty");
    }
    if (theme_ids.length > 5) {
      throw new BadRequestError("Maximum 5 theme IDs allowed");
    }
    shop.theme_ids = theme_ids || [];
    await shop.save();

    return {
      shop: getInfoData({
        fields: ["_id", "name", "theme_ids"],
        object: shop,
      }),
    };
  } catch (error) {
    throw error instanceof NotFoundError || error instanceof ForbiddenError
      ? error
      : new BadRequestError(error.message || "Failed to assign themes");
  }
};

const createSeat = async (req) => {
  try {
    const { shopId } = req.params;
    const { userId } = req.user;
    const { seat_name, description, is_premium, capacity } = req.body;
    const file = req.file;

    // Tìm quán
    const shop = await shopModel.findById(shopId);
    if (!shop) {
      throw new NotFoundError("Shop not found");
    }

    // Kiểm tra quyền
    if (shop.owner_id.toString() !== userId) {
      throw new ForbiddenError("You are not the owner of this shop");
    }

    // Kiểm tra input
    if (!seat_name || !capacity) {
      throw new BadRequestError("Seat name and capacity are required");
    }

    // Tạo ghế
    const seat = await shopSeatModel.create({
      shop_id: shopId,
      seat_name,
      description,
      image: file ? file.path : undefined,
      is_premium: is_premium || false,
      capacity,
    });

    return {
      seat: getInfoData({
        fields: [
          "_id",
          "shop_id",
          "seat_name",
          "description",
          "image",
          "is_premium",
          "is_available",
          "capacity",
        ],
        object: seat,
      }),
    };
  } catch (error) {
    if (req.file && req.file.filename) {
      await cloudinary.uploader.destroy(req.file.filename);
    }
    throw error instanceof NotFoundError || error instanceof ForbiddenError
      ? error
      : new BadRequestError(error.message || "Failed to create seat");
  }
};

const updateSeat = async (req) => {
  try {
    const { shopId, seatId } = req.params;
    const { userId } = req.user;
    const { seat_name, description, is_premium, is_available, capacity } = req.body;
    const file = req.file;

    // Tìm quán
    const shop = await shopModel.findById(shopId);
    if (!shop) {
      throw new NotFoundError("Shop not found");
    }

    // Kiểm tra quyền
    if (shop.owner_id.toString() !== userId) {
      throw new ForbiddenError("You are not the owner of this shop");
    }

    // Tìm ghế
    const seat = await shopSeatModel.findById(seatId);
    if (!seat) {
      throw new NotFoundError("Seat not found");
    }

    // Cập nhật dữ liệu
    const updateData = removeUndefinedObject({
      seat_name,
      description,
      is_premium,
      is_available,
      capacity,
      image: file ? file.path : undefined,
    });

    // Xóa ảnh cũ nếu có ảnh mới
    if (file && seat.image && seat.image.includes("cloudinary")) {
      const publicId = seat.image.split("/").pop().split(".")[0];
      await cloudinary.uploader.destroy(publicId);
    }

    const updatedSeat = await shopSeatModel
      .findByIdAndUpdate(seatId, updateData, { new: true, runValidators: true })
      .select(
        getSelectData([
          "_id",
          "shop_id",
          "seat_name",
          "description",
          "image",
          "is_premium",
          "is_available",
          "capacity",
        ])
      );

    return {
      seat: getInfoData({
        fields: [
          "_id",
          "shop_id",
          "seat_name",
          "description",
          "image",
          "is_premium",
          "is_available",
          "capacity",
        ],
        object: updatedSeat,
      }),
    };
  } catch (error) {
    if (req.file && req.file.filename) {
      await cloudinary.uploader.destroy(req.file.filename);
    }
    throw error instanceof NotFoundError || error instanceof ForbiddenError
      ? error
      : new BadRequestError(error.message || "Failed to update seat");
  }
};

const createMenuItem = async (req) => {
  try {
    const { shopId } = req.params;
    const { userId } = req.user;
    const { name, description, price, category, is_available } = req.body;

    // Kiểm tra shop tồn tại
    const shop = await shopModel.findById(shopId);
    if (!shop) {
      throw new NotFoundError("Shop not found");
    }

    // Kiểm tra quyền sở hữu
    if (shop.owner_id.toString() !== userId) {
      throw new ForbiddenError("You are not the owner of this shop");
    }

    // Kiểm tra danh mục
    if (!category) {
      throw new BadRequestError("Category is required");
    }
    const categoryExists = await menuItemCategoryModel.findById(category);
    if (!categoryExists) {
      throw new BadRequestError("Invalid category");
    }

    // Kiểm tra và xử lý ảnh
    let images = [];
    if (req.files && req.files.length > 0) {
      if (req.files.length > 3) {
        throw new BadRequestError("Maximum 3 images allowed");
      }
      images = await Promise.all(
        req.files.map(async (file) => {
          const result = await cloudinary.uploader.upload(file.path, {
            folder: `shops/${shopId}/menu-items`,
          });
          return { url: result.secure_url, publicId: result.public_id };
        })
      );
    } else {
      throw new BadRequestError("At least one image is required");
    }

    // Validate các trường bắt buộc
    if (!name || !price) {
      throw new BadRequestError("Name and price are required");
    }

    // Tạo menu item
    const menuItem = await shopMenuItemModel.create({
      shop_id: shopId,
      name,
      description,
      price: Number(price),
      category,
      is_available: is_available !== undefined ? is_available : true,
      images,
    });

    return {
      menuItem: getInfoData({
        fields: [
          "_id",
          "shop_id",
          "name",
          "description",
          "price",
          "category",
          "is_available",
          "images",
          "createdAt",
          "updatedAt",
        ],
        object: menuItem,
      }),
    };
  } catch (error) {
    if (req.files && req.files.length > 0) {
      await Promise.all(
        req.files.map((file) =>
          cloudinary.uploader.destroy(file.filename).catch((err) => console.error("Failed to delete image:", err))
        )
      );
    }
    throw error instanceof NotFoundError || error instanceof ForbiddenError
      ? error
      : new BadRequestError(error.message || "Failed to create menu item");
  }
};

const updateMenuItem = async (req) => {
  try {
    const { shopId, itemId } = req.params;
    const { userId } = req.user;
    const { name, description, price, category, is_available } = req.body;

    // Kiểm tra shop tồn tại
    const shop = await shopModel.findById(shopId);
    if (!shop) {
      throw new NotFoundError("Shop not found");
    }

    // Kiểm tra quyền sở hữu
    if (shop.owner_id.toString() !== userId) {
      throw new ForbiddenError("You are not the owner of this shop");
    }

    // Tìm menu item
    const menuItem = await shopMenuItemModel.findOne({ _id: itemId, shop_id: shopId });
    if (!menuItem) {
      throw new NotFoundError("Menu item not found");
    }

    // Kiểm tra danh mục nếu được cung cấp
    if (category) {
      const categoryExists = await menuItemCategoryModel.findById(category);
      if (!categoryExists) {
        throw new BadRequestError("Invalid category");
      }
    }

    // Xử lý ảnh
    let images = menuItem.images;
    if (req.files && req.files.length > 0) {
      if (req.files.length > 3) {
        throw new BadRequestError("Maximum 3 images allowed");
      }
      images = await Promise.all(
        req.files.map(async (file) => {
          const result = await cloudinary.uploader.upload(file.path, {
            folder: `shops/${shopId}/menu-items`,
          });
          return { url: result.secure_url, publicId: result.public_id };
        })
      );
      if (menuItem.images && menuItem.images.length > 0) {
        await Promise.all(
          menuItem.images.map((img) => cloudinary.uploader.destroy(img.publicId))
        );
      }
    } else if (req.body.images) {
      images = req.body.images;
      if (!Array.isArray(images) || images.length < 1 || images.length > 3) {
        throw new BadRequestError("Images must be an array with 1 to 3 items");
      }
      for (const img of images) {
        if (!img.url || !img.publicId) {
          throw new BadRequestError("Each image must have url and publicId");
        }
      }
      if (menuItem.images && menuItem.images.length > 0) {
        await Promise.all(
          menuItem.images.map((img) => cloudinary.uploader.destroy(img.publicId))
        );
      }
    }

    // Cập nhật menu item
    const updatedMenuItem = await shopMenuItemModel.findOneAndUpdate(
      { _id: itemId, shop_id: shopId },
      removeUndefinedObject({
        name,
        description,
        price: price ? Number(price) : undefined,
        category,
        is_available,
        images,
      }),
      { new: true }
    );

    return {
      menuItem: getInfoData({
        fields: [
          "_id",
          "shop_id",
          "name",
          "description",
          "price",
          "category",
          "is_available",
          "images",
          "createdAt",
          "updatedAt",
        ],
        object: updatedMenuItem,
      }),
    };
  } catch (error) {
    if (req.files && req.files.length > 0) {
      await Promise.all(
        req.files.map((file) =>
          cloudinary.uploader.destroy(file.filename).catch((err) => console.error("Failed to delete image:", err))
        )
      );
    }
    throw error instanceof NotFoundError || error instanceof ForbiddenError
      ? error
      : new BadRequestError(error.message || "Failed to update menu item");
  }
};

const createTimeSlot = async (req) => {
  try {
    const { shopId } = req.params;
    const { userId } = req.user;
    const {
      day_of_week,
      start_time,
      end_time,
      max_regular_reservations,
      max_premium_reservations,
      is_active,
    } = req.body;

    // Tìm quán
    const shop = await shopModel.findById(shopId);
    if (!shop) {
      throw new NotFoundError("Shop not found");
    }

    // Kiểm tra quyền
    if (shop.owner_id.toString() !== userId) {
      throw new ForbiddenError("You are not the owner of this shop");
    }

    // Kiểm tra input
    if (!day_of_week || !start_time || !end_time) {
      throw new BadRequestError(
        "Day of week, start time, and end time are required"
      );
    }

    // Tạo khung giờ
    const timeSlot = await shopTimeSlotModel.create({
      shop_id: shopId,
      day_of_week,
      start_time,
      end_time,
      max_regular_reservations,
      max_premium_reservations,
      is_active: is_active !== undefined ? is_active : true,
    });

    return {
      timeSlot: getInfoData({
        fields: [
          "_id",
          "shop_id",
          "day_of_week",
          "start_time",
          "end_time",
          "max_regular_reservations",
          "max_premium_reservations",
          "is_active",
        ],
        object: timeSlot,
      }),
    };
  } catch (error) {
    throw error instanceof NotFoundError || error instanceof ForbiddenError
      ? error
      : new BadRequestError(error.message || "Failed to create time slot");
  }
};

const updateTimeSlot = async (req) => {
  try {
    const { shopId, slotId } = req.params;
    const { userId } = req.user;
    const {
      day_of_week,
      start_time,
      end_time,
      max_regular_reservations,
      max_premium_reservations,
      is_active,
    } = req.body;

    // Tìm quán
    const shop = await shopModel.findById(shopId);
    if (!shop) {
      throw new NotFoundError("Shop not found");
    }

    // Kiểm tra quyền
    if (shop.owner_id.toString() !== userId) {
      throw new ForbiddenError("You are not the owner of this shop");
    }

    // Tìm khung giờ
    const timeSlot = await shopTimeSlotModel.findById(slotId);
    if (!timeSlot) {
      throw new NotFoundError("Time slot not found");
    }

    // Cập nhật dữ liệu
    const updateData = removeUndefinedObject({
      day_of_week,
      start_time,
      end_time,
      max_regular_reservations,
      max_premium_reservations,
      is_active,
    });

    const updatedTimeSlot = await shopTimeSlotModel
      .findByIdAndUpdate(slotId, updateData, { new: true, runValidators: true })
      .select(
        getSelectData([
          "_id",
          "shop_id",
          "day_of_week",
          "start_time",
          "end_time",
          "max_regular_reservations",
          "max_premium_reservations",
          "is_active",
        ])
      );

    return {
      timeSlot: getInfoData({
        fields: [
          "_id",
          "shop_id",
          "day_of_week",
          "start_time",
          "end_time",
          "max_regular_reservations",
          "max_premium_reservations",
          "is_active",
        ],
        object: updatedTimeSlot,
      }),
    };
  } catch (error) {
    throw error instanceof NotFoundError || error instanceof ForbiddenError
      ? error
      : new BadRequestError(error.message || "Failed to update time slot");
  }
};

const submitVerification = async (req) => {
  try {
    const { shopId } = req.params;
    const { userId } = req.user;
    const { document_type, reason } = req.body;

    // Kiểm tra shop tồn tại
    const shop = await shopModel.findById(shopId);
    if (!shop) {
      throw new NotFoundError("Shop not found");
    }

    // Kiểm tra quyền
    if (shop.owner_id.toString() !== userId) {
      throw new ForbiddenError("You are not the owner of this shop");
    }

    // Kiểm tra và xử lý ảnh
    let documents = [];
    if (req.files && req.files.length > 0) {
      // Validate số lượng ảnh
      if (req.files.length > 5) {
        throw new BadRequestError("Maximum 5 documents allowed");
      }
      documents = await Promise.all(
        req.files.map(async (file) => {
          const result = await cloudinary.uploader.upload(file.path, {
            folder: `shops/${shopId}/verifications`,
          });
          return { url: result.secure_url, publicId: result.public_id };
        })
      );
    } else {
      throw new BadRequestError("At least one document is required");
    }

    // Validate document_type
    if (!document_type) {
      throw new BadRequestError("Document type is required");
    }

    // Tạo xác minh
    const verification = await shopVerificationModel.create({
      shop_id: shopId,
      document_type,
      documents,
      reason,
      submitted_at: new Date(),
      status: "Pending",
    });

    return {
      verification: getInfoData({
        fields: [
          "_id",
          "shop_id",
          "document_type",
          "documents",
          "status",
          "submitted_at",
          "reason",
          "createdAt",
          "updatedAt",
        ],
        object: verification,
      }),
    };
  } catch (error) {
    // Xóa ảnh đã upload nếu có lỗi
    if (req.files && req.files.length > 0) {
      await Promise.all(
        req.files.map((file) =>
          cloudinary.uploader.destroy(file.filename).catch((err) => console.error("Failed to delete image:", err))
        )
      );
    }
    throw error instanceof NotFoundError || error instanceof ForbiddenError
      ? error
      : new BadRequestError(error.message || "Failed to submit verification");
  }
};




module.exports = {
  createShop,
  updateShop,
  getShop,
  uploadShopImage,
  assignThemes,
  createSeat,
  updateSeat,
  createMenuItem,
  updateMenuItem,
  createTimeSlot,
  updateTimeSlot,
  submitVerification,
  getAllShops,
  getAllPublicShops
};
